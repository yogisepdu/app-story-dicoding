export function generateSubscribeButtonTemplate() {
  return `<button id="subscribe-button" style="padding: 6px 12px; cursor: pointer;">Subscribe</button>`;
}
